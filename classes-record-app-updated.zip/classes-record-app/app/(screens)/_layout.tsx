import { Stack } from "expo-router";
import React from "react";

export default function ScreensLayout() {
  return <Stack screenOptions={{ headerShown: false }} />;
}
